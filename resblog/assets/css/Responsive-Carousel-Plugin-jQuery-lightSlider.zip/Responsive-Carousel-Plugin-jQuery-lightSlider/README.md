# LightSlider jQuery Plugin

by Razvan Zamfir

A lightweight jquery plugin for making responsive sliders.

It has detailed documentation. Enjoy the plugin.