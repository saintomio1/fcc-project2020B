$(document).ready(function() {
  $('ul.slider').lightSlider({
  	'slideDuration' : 300,
  	loop : true,
  	auto : true
  });
});